---
title: "Test event!"
categories: ["Talk","Workshop", "Other" ,"Social"]
date: 2024-01-10T08:30:00
location: "Union Bar"
---

Come to this event if you wanna see cool stuff!

### Subheading

Such as 

* this
* that
