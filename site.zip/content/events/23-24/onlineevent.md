---
title: "online event"
categories: ["talk"]
date: 2024-01-10T08:30:00
link: "https://teams.office.com/thisisreallyaverylonglinkisntit"
---

Come to this event if you wanna see cool stuff!

### Subheading

Such as 

* this
* that
