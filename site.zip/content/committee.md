---
title: "Committee"
menu: "main"
---

## Current Committee

as of xyz meeting, the current committe consists of:

* position - name (shortcode)
* position - name
* position - name


## Past

### ????-????

* position - name
