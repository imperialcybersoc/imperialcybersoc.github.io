---
title: "CTF Team"
menu: "main"
---

We also have a CTF team that takes part in CTF competitions ...

We meet every ??? in room ???. We are always looking for new members so please do stop by if you are interested!

someone put somethign here!!!

<!-- nick stuff from here: https://maplebacon.org/competitive_team/ -->